package com.capgemini.mobipur.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.mobipur.bean.Mobilebean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.util.DBConnection;

public class MobileDAOImp implements IMobileDAO {

	@Override
	public boolean updateMobile(int mobileId, int quantity)
			throws MobilePurchaseException {
		int records = 0;
		boolean isUpdated = false;
				
			try(Connection connMobiles = DBConnection.getInstance().getConnection();
					PreparedStatement preparedStatement =
					connMobiles.prepareStatement(QueryMapperMobiles.UPDATE_MOBILES))
				{
				preparedStatement.setString(1,Integer.toString(quantity));
				preparedStatement.setInt(2,mobileId);
				
				
				records = preparedStatement.executeUpdate();
				if(records > 0){
					isUpdated = true;
				}
			}catch (SQLException sqlEx) {
				throw new MobilePurchaseException(sqlEx.getMessage());
				// TODO: handle exception
			}
							
			// TODO Auto-generated method stub
			return isUpdated;
		// TODO Auto-generated method stub
			}

	@Override
	public List<Mobilebean> viewAll() throws MobilePurchaseException {
		
				List<Mobilebean>mobilesList = new ArrayList<Mobilebean>();
			try(Connection connMobiles = DBConnection.getInstance().getConnection();
					PreparedStatement preparedStatement =
					connMobiles.prepareStatement(QueryMapperMobiles.VIEW_MOBILES);
					ResultSet rsMobiles = preparedStatement.executeQuery();
				){
				
					while(rsMobiles.next()){
					Mobilebean mobiles = new Mobilebean();
					
					mobiles.setMobileId(rsMobiles.getInt("mobileId"));
					mobiles.setName(rsMobiles.getString("name"));
					mobiles.setPrice(rsMobiles.getFloat("price"));
					mobiles.setQuantity(rsMobiles.getString("quantity"));
				     
					mobilesList.add(mobiles);
				}
					if(mobilesList.size()== 0){
						throw new MobilePurchaseException("No records Found");
					}
			}
			catch (SQLException sqlEx) {
				throw new MobilePurchaseException(sqlEx.getMessage());
				// TODO: handle exception
			}
							
			// TODO Auto-generated method stub
			return mobilesList;
	}
 
	@Override
	public boolean deleteMobile(int mobileId) throws MobilePurchaseException {
		// TODO Auto-generated method stub
	
		
		int records = 0;
		boolean isDeleted = false;
				
			try(Connection connMobiles = DBConnection.getInstance().getConnection();
					PreparedStatement preparedStatement =
					connMobiles.prepareStatement(QueryMapperMobiles.DELETE_MOBILES))
				{
				java.sql.Date purchaseDate = new Date(new java.util.Date().getTime());
			
				preparedStatement.setInt(1,mobileId);
				
				
				records = preparedStatement.executeUpdate();
				if(records > 0){
					isDeleted = true;
				}
			}catch (SQLException sqlEx) {
				throw new MobilePurchaseException(sqlEx.getMessage());
				// TODO: handle exception
			}
							
			// TODO Auto-generated method stub
			return isDeleted;
	}

	@Override
	public List<Mobilebean> search(float minPrice, float maxPrice)
			throws MobilePurchaseException {
		// TODO Auto-generated method stub
		

		List<Mobilebean>mobilesList = new ArrayList<Mobilebean>();
	try(Connection connMobiles = DBConnection.getInstance().getConnection();
			PreparedStatement preparedStatement =
			connMobiles.prepareStatement(QueryMapperMobiles.SEARCH_MOBILES);
			
		){
		preparedStatement.setFloat(1, minPrice);
		preparedStatement.setFloat(2,maxPrice);
		
		ResultSet rsMobiles = preparedStatement.executeQuery();
			while(rsMobiles.next()){
			Mobilebean mobiles = new Mobilebean();
			
			mobiles.setMobileId(rsMobiles.getInt("mobileId"));
			mobiles.setName(rsMobiles.getString("name"));
			mobiles.setPrice(rsMobiles.getFloat("price"));
			mobiles.setQuantity(rsMobiles.getString("quantity"));
		     
			mobilesList.add(mobiles);
		}
			if(mobilesList.size()== 0){
				throw new MobilePurchaseException("No records Found");
			}
	}
	catch (SQLException sqlEx) {
		throw new MobilePurchaseException(sqlEx.getMessage());
		// TODO: handle exception
	}
					
	// TODO Auto-generated method stub
	return mobilesList;
	}

	@Override
	public int getQuantity(int mobileId) throws MobilePurchaseException {
		int mobileQty =0;
		try(Connection connMobiles = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement =
				connMobiles.prepareStatement(QueryMapperMobiles.GET_MOBILES);
				
			){
			preparedStatement.setInt(1, mobileId);

			
			ResultSet rsMobiles = preparedStatement.executeQuery();
				if (rsMobiles.next()){
					mobileQty = Integer.parseInt(rsMobiles.getString("Quantity"));
				
				
				}}
		catch (SQLException sqlEx) {
			throw new MobilePurchaseException(sqlEx.getMessage());
			// TODO: handle exception
		}
		return mobileQty;
		
	}

}
