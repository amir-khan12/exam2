package com.capgemini.mobipur.pi;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.mobipur.bean.Mobilebean;
import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.service.ServiceMobileimpl;
import com.capgemini.mobipur.service.ServicePurchaseimpl;

public class MobilePurchaseMain {
	private static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");

		boolean isInProcess = true;
		boolean isValid = false;
		byte choice = 0;

		String cname = null;
		String mailId = null;
		String phoneNO = null;
		Integer mobileId = 0;

		ServiceMobileimpl serviceMobile = new ServiceMobileimpl();
		ServicePurchaseimpl servicePurchaseMobile = new ServicePurchaseimpl();

		PurchaseDetailsBean purchaseDetailsBean = null;
		List<Mobilebean> mobileList = null;
		Scanner scInput = new Scanner(System.in);
		while (isInProcess) {
			System.out.println("1)Insert Mobile purchase.");
			System.out.println("2) View all mobiles");
			System.out.println("3) Deleat mobile details");
			System.out.println("4) Search mobiles for a range");
			System.out.println("0) Exit");
			choice = Byte.parseByte(scInput.nextLine());

			switch (choice) {
			case 1:
				while (!isValid) {
					try {
						System.out.println("Enter customer name;");
						cname = scInput.nextLine();

						isValid = servicePurchaseMobile.isValidCName(cname);

					} catch (MobilePurchaseException mpe) {
						logger.error("Invalid name:" + cname);
						System.out.println("Invalid name:" + cname);
						isValid = false;
					}
				}
				isValid = false;
				while (!isValid) {
					try {
						System.out.println("Enter mailId:");
						mailId = scInput.nextLine();

						isValid = servicePurchaseMobile.isValid(mailId);

					} catch (MobilePurchaseException mpe) {
						logger.error("Invalid mailId:" + mailId);
						isValid = false;
					}
				}

				isValid = false;

				while (!isValid) {
					try {
						System.out.println("Enter Phone No:");
						phoneNO = scInput.nextLine();

						isValid = servicePurchaseMobile.isValidPhoneNo(phoneNO);

					} catch (MobilePurchaseException mpe) {
						logger.error("Invalid phone no :" + mailId);
						isValid = false;
					}
				}

				isValid = false;

				while (!isValid) {
					try {
						System.out.println("Enter MobileId:");
						mobileId = Integer.parseInt(scInput.nextLine());

						isValid = serviceMobile.isValidMobileId(mobileId);

					} catch (MobilePurchaseException mpe) {
						logger.error("Invalid mobileId:" + mobileId);
						isValid = false;
					}

				}

				purchaseDetailsBean = new PurchaseDetailsBean(cname, mailId,
						phoneNO, mobileId);
				try {
					servicePurchaseMobile
							.ISertPurchaseDetails(purchaseDetailsBean);
				} catch (MobilePurchaseException e) {
					logger.error(e.getMessage());
				}
				break;

			case 2:
				try {
					mobileList = serviceMobile.ViewAll();

					for (Mobilebean mobilebean : mobileList) {
						System.out.println(mobilebean);
					}
					System.out
							.println("=======================================");

				} catch (MobilePurchaseException e) {
					logger.error(e.getMessage());

				}
				break;

			case 3:
				isValid = false;

				while (!isValid) {
					try {
						System.out.println("Enter Mobile Id:");
						mobileId = Integer.parseInt(scInput.nextLine());

						isValid = serviceMobile.isValidMobileId(mobileId);

					} catch (MobilePurchaseException mpe) {
						logger.error("Invalid mobileId:" + mobileId);
						isValid = false;
					}
				}

				try {

					boolean isDeleted = serviceMobile.deleteMobile(mobileId);
					if (isDeleted) {
						System.out
								.println("Mobile record deleated successfully");
					}

				} catch (MobilePurchaseException e) {
					logger.error(e.getMessage());
					// TODO: handle exception
				}
				break;

			case 4:
				float minPrice = 0;
				float maxPrice = 0;

				System.out.println("Enter minimum price:");
				minPrice = Float.parseFloat(scInput.nextLine());

				System.out.println("Enter maximum price:");
				maxPrice = Float.parseFloat(scInput.nextLine());
				try {
					mobileList = serviceMobile.search(minPrice, maxPrice);
					for (Mobilebean mobilebean : mobileList) {
						System.out.println(mobilebean);
					}
					System.out.println("=======================");
				} catch (MobilePurchaseException e) {
					logger.error(e.getMessage());
					// TODO: handle exception
				}
				break;
			case 0:
				isInProcess = false;
				break;
			default:
				System.out.println("Invalid Input");
				logger.error("Invalid Input" + choice);
				break;
			}
		}
		scInput.close();
	}
}

/*
 * PurchaseDetailsBean pdb = new Purchase
 * DetailsBean("abc","abc@ab.com","99888",1002);
 * 
 * IServicePurchaseMobile isp = new ServicePurchaseimpl(); try{ boolean
 * isInserted = isp.ISertPurchaseDetails(pdb);
 * 
 * if(isInserted){ System.out.println("Record Insertrd Successfully"); }
 * }catch(MobilePurchaseException mpe){ System.out.println(mpe.getMessage()); }
 */
