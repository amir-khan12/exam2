package com.capgemini.mobipur.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.mobipur.bean.Mobilebean;
import com.capgemini.mobipur.dao.IMobileDAO;
import com.capgemini.mobipur.dao.IpurchaseDetailsDAO;
import com.capgemini.mobipur.dao.MobileDAOImp;
import com.capgemini.mobipur.dao.PurchaseDetailsDAOimpf;
import com.capgemini.mobipur.exception.MobilePurchaseException;

public class ServiceMobileimpl implements IServiceMobile {
	private IMobileDAO mobileDAO;
	
	public ServiceMobileimpl(){
		mobileDAO = new MobileDAOImp();
	}
	
	
	
	
	@Override
	public List<Mobilebean> ViewAll() throws MobilePurchaseException {
		List<Mobilebean> mobileList = mobileDAO.viewAll();
		return mobileList;
	
	}

	@Override
	public boolean deleteMobile(int mobileId) throws MobilePurchaseException {
		IpurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOimpf();
		boolean isPurchaseDeleted = purchaseDetailsDAO.deleatPurchaseDetais(mobileId);
		boolean isDeleted = mobileDAO.deleteMobile(mobileId);
		return(isDeleted && isPurchaseDeleted);
	}

	@Override
	public List<Mobilebean> search(float miniprice, float maxPrice)
			throws MobilePurchaseException {
		List<Mobilebean>mobileList = mobileDAO.search(miniprice, maxPrice);
		return mobileList;
	}
	 public boolean isValidMobileId(int mobileId) throws MobilePurchaseException{
		 boolean isValid = false;
		 String mobile = Integer.toString(mobileId);
		 String pattern = "[\\d]{4}";
		 
		 Pattern ptn = Pattern.compile(pattern) ;
		 Matcher matcher = ptn.matcher(mobile);
		 isValid = matcher.matches();
		 //isValid = Pattern.matches(mobile,pattern);
		  return isValid;

}}
