package com.capgemini.mobipur.test;


import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.service.IServicePurchaseMobile;
import com.capgemini.mobipur.service.ServicePurchaseimpl;

public class ServicePurchaseimplTest {
private PurchaseDetailsBean PurchaseDetailsBean;
	
	@Before
	public void setUp() throws Exception {
		PurchaseDetailsBean = new PurchaseDetailsBean("abc","abc@ab.com","99888",1002);
		
	}
	

	@After
	public void tearDown() throws Exception {
		PurchaseDetailsBean = null;
		
	}

	@Test
	public final void testISertPurchaseDetails() {
		IServicePurchaseMobile servicePurchaseMobile = new ServicePurchaseimpl();
		try {
			assertTrue(servicePurchaseMobile.ISertPurchaseDetails(PurchaseDetailsBean));
		} catch (MobilePurchaseException e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

}
