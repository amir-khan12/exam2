import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.service.EmployeeServiceImpl;
import com.capgemini.employee.service.IEmployeeService;




public class EmployeeServiceImplTest {

	private IEmployeeService serviceEmployee;
	@Before
	public void setUp() throws Exception {
		serviceEmployee = new  EmployeeServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		serviceEmployee=null;
	}

	@Test
	public final void test() {
		try{
			boolean isUpdated=serviceEmployee.updateEmployee(1002,40000);
			assertTrue("No such mobile",isUpdated==true);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
	}

}
