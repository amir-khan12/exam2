package com.capgemini.employee.service;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;



public interface IEmployeeService {

	public boolean insertEmployee(final EmployeeBean employeeBean) 
			throws EmployeeException;

	public boolean deleteEmployee(final int empId)
			throws EmployeeException;
	
	public boolean updateEmployee(final int empId,final int salary)
			throws EmployeeException;
}
