package dao;

public interface QueryMapperEmployee {
      
	
    public static final  String UPDATE_EMPLOYEE = "UPDATE employee SET salary = ? WHERE empId= ?";
	
	public static final String DELETE_EMPLOYEE = "DELETE FROM employee WHERE empId=?";
	
	public static final String VIEW_EMPLOYEE = "SELECT empId, empName, salary,empDept,empDesignation FROM employee";
	
	public static final String INSERT_EMPLOYEE = "INSERT INTO employee values('?','?','?','?',?')";
}
