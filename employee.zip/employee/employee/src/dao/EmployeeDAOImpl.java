package dao;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	import java.util.List;

	

	import dao.QueryMapperEmployee;
	import exception.EmployeeDetailException;
	import util.DBConnection;

	import bean.EmployeeBean;

public class EmployeeDAOImpl implements IEmployeeDAO {

		@Override
		public boolean updateEmployee(int empId, float salary) throws EmployeeDetailException {
			int records =0;
			boolean isUpdated = false;
			
			try(Connection connEmployee = DBConnection.getInstance().getConnection();	
					PreparedStatement preparedStatement=
							connEmployee.prepareStatement(QueryMapperEmployee.UPDATE_EMPLOYEE);
					){
				preparedStatement.setString(1, Float.toString( salary));
				preparedStatement.setInt(2, empId);
				
				records = preparedStatement.executeUpdate();
				
				if(records >0){
					isUpdated= true;
				}
			}catch(SQLException sqlEx){
				throw new EmployeeDetailException(sqlEx.getMessage());
			}
			return isUpdated;
		}

		@Override
		public List<EmployeeBean> viewAll() throws EmployeeDetailException {
		List<EmployeeBean>employeeList = new ArrayList<EmployeeBean>();
			
			try(Connection connEmployee = DBConnection.getInstance().getConnection();	
					PreparedStatement preparedStatement=
							connEmployee.prepareStatement(QueryMapperEmployee.VIEW_EMPLOYEE);
					ResultSet rsEmployee = preparedStatement.executeQuery();
					){
				while(rsEmployee.next()){
					EmployeeBean employee = new EmployeeBean();
					
					employee.setEmpId(rsEmployee.getInt("employeeid"));
					employee.setEmpName(rsEmployee.getString("name"));
					employee.setEmpSalary(rsEmployee.getFloat("salary"));
					employee.setEmpDept(rsEmployee.getString("department"));
					employee.setEmpDesignation(rsEmployee.getString("designation"));
					
					employeeList.add(employee);
				}
				
				if(employeeList.size()==0){
					throw new EmployeeDetailException("No records found.");
				}
			}catch(SQLException sqlEx){
				throw new EmployeeDetailException(sqlEx.getMessage());
			}
			return employeeList;
		}

		@Override
		public boolean deleteEmployee(int empId) throws EmployeeDetailException {
			int records =0;
			boolean isDeleted = false;
			
			try(Connection connEmployee = DBConnection.getInstance().getConnection();	
					PreparedStatement preparedStatement=
							connEmployee.prepareStatement(QueryMapperEmployee.DELETE_EMPLOYEE);
					){
				preparedStatement.setInt(1, empId);
				
				records = preparedStatement.executeUpdate();
				
				if(records >0){
					isDeleted= true;
				}
			}catch(SQLException sqlEx){
				throw new EmployeeDetailException(sqlEx.getMessage());
			}
			return isDeleted;
		
		}
		
		
	@Override
	public boolean insert(int empId, String empName, float salary, String empDept, String empDesignation)
			throws EmployeeDetailException {
		// TODO Auto-generated method stub
		return false;
	}

}
