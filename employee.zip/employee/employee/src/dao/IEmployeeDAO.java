package dao;

import java.util.List;

import bean.EmployeeBean;
import exception.EmployeeDetailException;

public interface IEmployeeDAO {

public boolean updateEmployee(final int empId, final float salary ) throws EmployeeDetailException;
	
	public List<EmployeeBean> viewAll() throws EmployeeDetailException;
	
	public boolean deleteEmployee(final int empId)throws EmployeeDetailException;
	
	public boolean insert(final int empId,String empName,final float salary,String empDept,String empDesignation) throws EmployeeDetailException;
	
}
