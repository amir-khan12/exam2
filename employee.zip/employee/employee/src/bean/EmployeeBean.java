package bean;

public class EmployeeBean {
	private int empId;
	private String empName;
	private float empSalary;
	private String empDept;
	private String empDesignation;
	
	
	public EmployeeBean() {
		super();
	}


	public EmployeeBean(int empId, String empName, float empSalary, String empDept, String empDesignation) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDept = empDept;
		this.empDesignation = empDesignation;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public float getEmpSalary() {
		return empSalary;
	}


	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
	}


	public String getEmpDept() {
		return empDept;
	}


	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}


	public String getEmpDesignation() {
		return empDesignation;
	}


	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}


	@Override
	public String toString() {
		return "EmployeeBean [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDept="
				+ empDept + ", empDesignation=" + empDesignation + "]";
	}
	
}
