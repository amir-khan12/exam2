package exception;

public class EmployeeDetailException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7290476975593304142L;
	/**
	 * 
	 */
	public EmployeeDetailException(){
		super();
	}
	public EmployeeDetailException(String message) {
		super(message);
		
	}
}
